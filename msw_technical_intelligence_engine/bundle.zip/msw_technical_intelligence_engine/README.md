# MSW Technical Intelligence Engine 5.0

Independent FastAPI engine on Render, public read-only catalog. **Not a replacement for WordPress or existing MSW Arena.**

Contains (from the editorial MSW Technical University 360 dataset):
- 40 technical families, 1000 internally defined technical micro-specializations and 1000 agent templates (NOT active agents);
- 1200 editorial lessons, 1600 educational labs across 20 tracks; not hardware-certified;
- 61 calculator specifications (descriptions, not all executed calculators);
- integration status descriptions and analytic local 2-qubit Bell simulation; no connection to real quantum hardware;
- research source manifest, unreviewed candidates and a bounded link audit;
- a daily lesson assignment plan (planning, not actual LLM inference).

## Local development

```sh
pip install -r msw_technical_intelligence_engine/requirements.txt
uvicorn msw_technical_intelligence_engine.app:app --reload
pytest -q msw_technical_intelligence_engine/tests
```

## Render web service

Source repository: `https://github.com/flyxpressWarszawa/KonyWarsaw`, branch `main`.

- Runtime Python 3, Frankfurt, free for evaluation (cold starts / no uptime SLA).
- Build: `pip install -r msw_technical_intelligence_engine/requirements.txt`
- Start: `uvicorn msw_technical_intelligence_engine.app:app --host 0.0.0.0 --port $PORT`
- `/health` verifies *only* the catalogue service, not the quantum hardware, WordPress or external models.

## Research automation

`.github/workflows/msw-technical-research.yml` uses GitHub Actions to check fixed public official feeds, store metadata under **pending review** and boundedly check page URLs; if pushes succeed Render auto-deploys the updated read-only snapshot. No automatic approvals, device control, unsolicited messages or model-weight updates. If GitHub Actions lacks `contents:write` permissions, this workflow will fail until repo admin authorizes that permission.

Research source metadata is untrusted. All data remains in a distinct unreviewed research area. The daily ChatGPT research automation also exists separately and must not be duplicated.

## Security and caveats

- No public registration/agent POST endpoints activate physical devices or accept secret credentials.
- The non-authenticated catalog is informational; it should not expose private logs, keys, addresses, photographs, or personal data.
- Google real Quantum Computing Service is access-restricted; IBM Open Plan needs user account/token; NASA QuAIL is research not a public QPU service; Xanadu hardware access depends on the provider. The `/api/quantum/bell` demo is CPU analytic calculation only.
- The 1000 taxonomy entries are an **original MSW educational taxonomy**, based on 40 families, not a verbatim import of ESCO, UNESCO or IEEE and not a proof of recognized 1000 scientific disciplines.
- No direct persistent database is connected. The engine is a *read-only knowledge index* until an authenticated database bridge is deployed and verified.

## WordPress Integration

Keep existing MSW University 1.0, Program 1200/Lab 1600 4.0, Atlas 4.0.1, Research Mesh 2.0 and TechLab 3.1 intact. Link to the standalone technical engine from a NEW WordPress menu/page when WP connection write capability becomes available; do not replace old published pages.
