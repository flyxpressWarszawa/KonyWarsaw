"""MSW standalone technical intelligence engine."""
