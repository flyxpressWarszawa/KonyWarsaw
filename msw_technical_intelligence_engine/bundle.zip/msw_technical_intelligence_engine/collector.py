"""Fixed-source daily public research + bounded owned-domain link audit.

Designed for GitHub Actions, no WordPress admin credentials, no LLM training.
All harvested feed items stay *pending human review*.
"""
from __future__ import annotations

import datetime as dt
import html
import json
import pathlib
import re
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from typing import Any

BASE = pathlib.Path(__file__).resolve().parent
RESEARCH = BASE / 'research'
PROJECT = 'https://mobilny-serwis-warszawa.pl'
RSS = [
    ('qiskit','https://github.com/Qiskit/qiskit/releases.atom'),
    ('cirq','https://github.com/quantumlib/Cirq/releases.atom'),
    ('pennylane','https://github.com/PennyLaneAI/pennylane/releases.atom'),
    ('nasa','https://www.nasa.gov/feed/'),
    ('homeassistant','https://github.com/home-assistant/core/releases.atom'),
    ('esphome','https://github.com/esphome/esphome/releases.atom'),
    ('espidf','https://github.com/espressif/esp-idf/releases.atom'),
    ('zephyr','https://github.com/zephyrproject-rtos/zephyr/releases.atom'),
    ('open62541','https://github.com/open62541/open62541/releases.atom'),
    ('ros2','https://github.com/ros2/ros2/releases.atom'),
    ('openems','https://github.com/OpenEMS/openems/releases.atom'),
    ('zigbee2mqtt','https://github.com/Koenkk/zigbee2mqtt/releases.atom'),
    ('pythoncan','https://github.com/hardbyte/python-can/releases.atom'),
    ('micropython','https://github.com/micropython/micropython/releases.atom'),
]
SITEMAP_URLS = [PROJECT+'/sitemap_index.xml', PROJECT+'/wp-sitemap.xml']
SLUGS = ['centrum-technicznych-ai','gielda-technologii-ai','arena-diagnostyki-ai',
         'kreator-agentow-technicznych-ai','ai-w-inteligentnym-domu','ai-diagnostyka-pojazdow',
         'ai-automatyka-maszyn','ai-energia-ev-i-hvac','ai-integracje-i-api',
         'katalog-agentow-technicznych','sklep-modulow-ai-iot','projekty-inzynierii-ai',
         'monitoring-botow-i-systemow','baza-wiedzy-technicznej-ai','ai-automatyzacja-dla-firm',
         'msw-technical-university','msw-technical-university-program-nauki-ai',
         'msw-ai-centrum-robotow','arena-robotow-ai','gielda-ai-robotow','kreator-robotow-ai']
ALLOWED_RESEARCH_DOMAINS = {'github.com','www.nasa.gov','nasa.gov','science.nasa.gov'}
MAX_FEED_BYTES = 400_000
MAX_SITE_BYTES = 200_000


def utcnow():
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec='seconds')


def safe_url(u: str, purpose: str) -> bool:
    try:
        parts=urllib.parse.urlsplit(u)
        if parts.scheme!='https' or parts.username or parts.password or parts.port is not None: return False
        host=(parts.hostname or '').lower()
        if purpose=='site': return host in {'mobilny-serwis-warszawa.pl','www.mobilny-serwis-warszawa.pl'}
        return host in ALLOWED_RESEARCH_DOMAINS
    except ValueError:return False


class BlockUnsafeRedirect(urllib.request.HTTPRedirectHandler):
    def __init__(self, purpose):super().__init__();self.purpose=purpose
    def redirect_request(self,req,fp,code,msg,headers,newurl):
        if not safe_url(newurl,self.purpose):raise ValueError('Blocked redirect to another host')
        return super().redirect_request(req,fp,code,msg,headers,newurl)


def fetch(url:str, *, purpose:str, limit:int, timeout:int=9):
    if not safe_url(url,purpose):raise ValueError('URL not in allowed source list')
    op=urllib.request.build_opener(BlockUnsafeRedirect(purpose))
    request=urllib.request.Request(url,headers={'User-Agent':'MSW-Technical-Research/5.0 (public docs; max 1 req/s)', 'Accept':'application/atom+xml,application/rss+xml,application/xml,text/html;q=0.7'})
    with op.open(request,timeout=timeout) as r:
        code=r.status
        data=r.read(limit+1)
        if len(data)>limit:raise ValueError('Response size exceeds a safe cap')
        return int(code),data,r.geturl()


def clean(v:str,maxlen:int=180)->str:
    return html.unescape(re.sub(r'<[^>]+>', '', v or '')).strip()[:maxlen]


def feed_items(body:bytes, source_id:str):
    try:root=ET.fromstring(body)
    except ET.ParseError:return []
    out=[]
    atom='{http://www.w3.org/2005/Atom}'
    if root.tag.endswith('feed'):
        for item in root.findall(atom+'entry')[:8]:
            url=''
            for link in item.findall(atom+'link'):
                if link.attrib.get('rel','alternate')=='alternate':url=link.attrib.get('href','');break
            title=clean(item.findtext(atom+'title',''))
            when=clean(item.findtext(atom+'updated','') or item.findtext(atom+'published',''),45)
            if title and url.startswith('https://'):
                out.append({'source':source_id,'title':title,'url':url[:500], 'published':when, 'reviewed':False,'status':'source_candidate_unverified'})
    else:
        for item in root.findall('.//item')[:8]:
            title=clean(item.findtext('title',''))
            url=clean(item.findtext('link',''),500)
            when=clean(item.findtext('pubDate',''),50)
            if title and url.startswith('https://'):
                out.append({'source':source_id,'title':title,'url':url,'published':when,'reviewed':False,'status':'source_candidate_unverified'})
    return out


def read_json(path):
    try:return json.loads(path.read_text('utf-8'))
    except (OSError, ValueError):return {}


def atomic_json(path: pathlib.Path,obj:dict):
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(obj,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    tmp.replace(path)


def research():
    previous=read_json(RESEARCH/'candidates.json')
    candidates={ (v.get('source'),v.get('url')):v for v in previous.get('items',[]) if isinstance(v,dict) }
    statuses=[]
    for source,url in RSS:
        try:
            code,body,final=fetch(url,purpose='feed',limit=MAX_FEED_BYTES)
            collected=feed_items(body,source)
            for item in collected:candidates[(source,item['url'])]=item
            statuses.append({'id':source,'http':code,'new_or_existing':len(collected),'error':None})
        except Exception as exc:
            statuses.append({'id':source,'http':None,'new_or_existing':0,'error':str(exc)[:120]})
        time.sleep(.08)
    vals=sorted(candidates.values(),key=lambda x:(x.get('published',''),x.get('source','')),reverse=True)[:110]
    successes=sum(1 for x in statuses if x['http']==200)
    result={'status':'completed' if successes==len(RSS) else 'partial' if successes else 'failed',
            'checked_at':utcnow(),'sources_checked':len(statuses),'sources_ok':successes,
            'feeds':statuses,'items':vals,'moderation':'all source candidates remain pending human review',
            'automatic_publication':False,'weights_training':False}
    atomic_json(RESEARCH/'candidates.json',result)
    return result


def extract_sitemap(data:bytes)->list[str]:
    root=ET.fromstring(data)
    out=[]
    for e in root.iter():
        if e.tag.endswith('loc') and e.text:
            u=e.text.strip()
            if safe_url(u,'site'):out.append(u)
    return out


def audit():
    previous=read_json(RESEARCH/'link-audit.json')
    candidates=[PROJECT+'/'+slug+'/' for slug in SLUGS]
    sitemap_failed=[]
    for src in SITEMAP_URLS:
        try:
            _,body,_=fetch(src,purpose='site',limit=MAX_SITE_BYTES)
            urls=extract_sitemap(body)
            if not urls:continue
            for u in urls[:10]:
                if u.endswith('.xml'):
                    try:
                        _,content,_=fetch(u,purpose='site',limit=MAX_SITE_BYTES)
                        candidates.extend([x for x in extract_sitemap(content) if not x.endswith('.xml')][:220])
                    except Exception as e:sitemap_failed.append(str(e)[:100])
                else:candidates.append(u)
            break
        except Exception as e:sitemap_failed.append(str(e)[:100])
    # Gradual audit: up to 30 endpoints/day, always 15+ project URLs plus rotating rest.
    candidates=list(dict.fromkeys(u for u in candidates if safe_url(u,'site')))
    offset=int(previous.get('next_offset',0))
    fixed=candidates[:min(len(SLUGS),21)]
    other=candidates[len(fixed):]
    rotating=[other[(offset+i)%len(other)] for i in range(min(9,len(other)))] if other else []
    sample=list(dict.fromkeys(fixed+rotating))[:30]
    results=[]
    for url in sample:
        try:
            code,body,final=fetch(url,purpose='site',limit=MAX_SITE_BYTES)
            results.append({'url':url,'http_status':code,'final_url':final,'checked':utcnow(),
                            'html_bytes_sampled':len(body),'result':'http_ok' if 200<=code<300 else 'http_error',
                            'semantic_content_quality':'not_assessed'})
        except Exception as e:
            results.append({'url':url,'http_status':None,'checked':utcnow(), 'result':'check_failed','error':str(e)[:150]})
        time.sleep(.11)
    success=sum(1 for x in results if x.get('result')=='http_ok')
    result={'status':'completed_partial_site_audit','checked_at':utcnow(), 'results':results,
            'checked_count':len(results),'http_ok':success,'http_failed':len(results)-success,
            'next_offset':offset+len(rotating),'discovered_owned_urls':len(candidates),
            'all_pages_checked':False,'all_links_checked':False,'scope':'selected MSW pages plus rotated bounded sitemap sampling',
            'sitemap_errors':sitemap_failed[:5],'note':'200 alone does not prove content accuracy, layout quality or functioning JS.'}
    atomic_json(RESEARCH/'link-audit.json',result)
    return result


if __name__=='__main__':
    a=research();b=audit()
    print(json.dumps({'research_status':a['status'],'research_feeds_ok':a['sources_ok'],
                      'audit_checked':b['checked_count'],'audit_http_ok':b['http_ok']},ensure_ascii=False))
