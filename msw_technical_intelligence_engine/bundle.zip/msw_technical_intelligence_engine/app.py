"""MSW Technical Intelligence Engine 5.0.

Public read-only gateway to an original, versioned technical curriculum.
Zero hardware, credential or real-time telemetry claims are inferred from presence of an integration description.
Research candidates remain UNREVIEWED and are never injected into approved knowledge automatically.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import math
import os
import tarfile
from datetime import datetime, timezone
from functools import lru_cache
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

HERE = Path(__file__).resolve().parent
DATAFILE = HERE / 'data' / 'msw-curriculum.tar.gz'
APP_VERSION = '5.0.0'
MAX_QUERY = 100

@lru_cache(maxsize=35)
def get_data(filename: str) -> Any:
    approved = {'manifest.json', 'msw360-manifest.json', 'families.json', 'taxonomy.json',
                'agents.json', 'index.json', 'tracks.json', 'calculators.json'}
    if filename not in approved and not (filename.startswith('tracks/') and filename.endswith('.json')
                                        and filename[7:-5].replace('-', '').isalnum()):
        raise ValueError('File is not in allowlist')
    with tarfile.open(DATAFILE, 'r:gz') as archive:
        try:
            member = archive.getmember(filename)
        except KeyError as exc:
            raise KeyError(filename) from exc
        data = archive.extractfile(member)
        if not data or member.size > 1_500_000:
            raise ValueError('Invalid data resource')
        return json.loads(data.read())

FAMILIES = get_data('families.json')
TRACKS = get_data('tracks.json')
TAXONOMY = get_data('taxonomy.json')
AGENTS = get_data('agents.json')
INDEX = get_data('index.json')
TOOLS = get_data('calculators.json')
LESSONS = [x for x in INDEX if x['kind'] == 'lesson']
LABS = [x for x in INDEX if x['kind'] == 'lab']
INDEX_BY_ID = {x['id']: x for x in INDEX}
assert (len(FAMILIES), len(TAXONOMY), len(AGENTS), len(LESSONS), len(LABS), len(TOOLS)) == (40, 1000, 1000, 1200, 1600, 61)

SOURCES = [
    {'id':'matter','name':'Connectivity Standards Alliance · Matter', 'url':'https://csa-iot.org/all-solutions/matter/', 'type':'official-docs'},
    {'id':'qiskit','name':'Qiskit releases', 'url':'https://github.com/Qiskit/qiskit/releases.atom', 'type':'atom'},
    {'id':'cirq','name':'Google Cirq releases', 'url':'https://github.com/quantumlib/Cirq/releases.atom', 'type':'atom'},
    {'id':'pennylane','name':'PennyLane releases', 'url':'https://github.com/PennyLaneAI/pennylane/releases.atom', 'type':'atom'},
    {'id':'nasa','name':'NASA research', 'url':'https://www.nasa.gov/feed/', 'type':'rss'},
    {'id':'homeassistant','name':'Home Assistant releases', 'url':'https://github.com/home-assistant/core/releases.atom', 'type':'atom'},
    {'id':'esphome','name':'ESPHome releases', 'url':'https://github.com/esphome/esphome/releases.atom', 'type':'atom'},
    {'id':'espidf','name':'Espressif ESP-IDF releases', 'url':'https://github.com/espressif/esp-idf/releases.atom', 'type':'atom'},
    {'id':'zephyr','name':'Zephyr RTOS releases', 'url':'https://github.com/zephyrproject-rtos/zephyr/releases.atom', 'type':'atom'},
    {'id':'open62541','name':'Open62541 OPC UA', 'url':'https://github.com/open62541/open62541/releases.atom', 'type':'atom'},
    {'id':'ros2','name':'ROS 2 releases', 'url':'https://github.com/ros2/ros2/releases.atom', 'type':'atom'},
    {'id':'openems','name':'OpenEMS energy management', 'url':'https://github.com/OpenEMS/openems/releases.atom', 'type':'atom'},
    {'id':'zigbee2mqtt','name':'Zigbee2MQTT releases', 'url':'https://github.com/Koenkk/zigbee2mqtt/releases.atom', 'type':'atom'},
    {'id':'pythoncan','name':'python-can releases', 'url':'https://github.com/hardbyte/python-can/releases.atom', 'type':'atom'},
    {'id':'micropython','name':'MicroPython releases', 'url':'https://github.com/micropython/micropython/releases.atom', 'type':'atom'},
]
SOURCES_BY_ID = {s['id']: s for s in SOURCES}
PAGES = [
    ('Centrum AI','centrum-technicznych-ai'),('Giełda Technologii AI','gielda-technologii-ai'),
    ('Arena Diagnostyki','arena-diagnostyki-ai'),('Kreator Agentów','kreator-agentow-technicznych-ai'),
    ('Smart Home','ai-w-inteligentnym-domu'),('Pojazdy','ai-diagnostyka-pojazdow'),
    ('Mechatronika i maszyny','ai-automatyka-maszyn'),('EV / HVAC','ai-energia-ev-i-hvac'),
    ('Integracje API','ai-integracje-i-api'),('Agenci','katalog-agentow-technicznych'),
    ('Moduły IoT','sklep-modulow-ai-iot'),('Projekty inżynieryjne','projekty-inzynierii-ai'),
    ('Monitoring','monitoring-botow-i-systemow'),('Baza wiedzy','baza-wiedzy-technicznej-ai'),
    ('Automatyzacja firm','ai-automatyzacja-dla-firm'),('MSW Technical University','msw-technical-university'),
]

QUANTUM = [
    {'name':'IBM Quantum','software':'Qiskit','simulation':'open source locally',
     'real_hardware':'requires_authorized_open_or_paid_account','connected':False,
     'docs':'https://quantum.cloud.ibm.com/docs/en/guides/plans-overview'},
    {'name':'Google Quantum AI','software':'Cirq','simulation':'local_available',
     'real_hardware':'restricted_to_approved_groups','connected':False,
     'docs':'https://quantumai.google/cirq/google/access'},
    {'name':'NASA QuAIL','software':'HybridQ','simulation':'open_source_local',
     'real_hardware':'not_a_public_general_purpose_QPU_service','connected':False,
     'docs':'https://www.nasa.gov/intelligent-systems-division/discovery-and-systems-health/nasa-quail/'},
    {'name':'Photonic / Xanadu','software':'PennyLane, Strawberry Fields','simulation':'local_available_if_installed',
     'real_hardware':'requires_provider_access','connected':False,
     'docs':'https://strawberryfields.ai/'},
]
ENGINE_ADAPTERS = [
    {'name':'University 1.0','rest_route':'/wp-json/msw-university/v1/catalog','mode':'read_approved','verified':'route_observed_previous_turn_not_current_test'},
    {'name':'Neural Suite','rest_route':'/wp-json/msw-neural/v1/status','mode':'read_status','verified':'responded_200_2026-10-24'},
    {'name':'Meta Engine','rest_route':'/wp-json/msw-evolution/v2/report','mode':'read_status','verified':'responded_200_2026-10-24'},
    {'name':'Evolutionary Meta-Core','rest_route':'/wp-json/msw-evo/v1/status','mode':'read_status','verified':'responded_200_2026-10-24'},
    {'name':'Search & Learn','rest_route':'/wp-json/msw-ai/v1/search','mode':'unknown','verified':'no_safe_status_test'},
    {'name':'Python HUB','rest_route':'/wp-json/msw-hub/v1/status','mode':'read_status','verified':'responded_200_2026-10-24'},
    {'name':'University Research Mesh','rest_route':None,'mode':'research_proposals','verified':'active_plugin_only_endpoint_unverified'},
]

app = FastAPI(title='MSW Technical Intelligence Engine', version=APP_VERSION,
              description='Techniczne API: uczelnia, katalog AI, plan nauki, źródła i symulacje kwantowe. Bez zdalnego sterowania urządzeniami.',
              docs_url='/api/docs', redoc_url=None)


def _page(items: list | tuple, page: int, size: int) -> dict:
    return {'items':items[(page-1)*size:page*size], 'total':len(items), 'page':page,
            'page_size':size, 'pages':math.ceil(len(items)/size)}


def _filter(items: list[dict], q: str, group: str, fields: tuple[str,...]) -> list[dict]:
    term=q.strip().casefold()
    result=items
    if group:
        result=[x for x in result if (x.get('group') or x.get('macro_domain') or '')==group]
    if term:
        result=[x for x in result if any(term in str(x.get(k,'' )).casefold() for k in fields)]
    return result


@app.get('/')
def homepage():
    return FileResponse(HERE/'site.html', media_type='text/html', headers={'Cache-Control':'public, max-age=300'})

@app.get('/health')
def health():
    return {'status':'ok','version':APP_VERSION,'data_loaded':True, 'db_persistent':False,
            'hardware_connected':False,'model_weight_training':False}

@app.get('/api/status')
def status():
    doc=get_data('msw360-manifest.json')
    research=load_report('research/candidates.json')
    audit=load_report('research/link-audit.json')
    return {'name':'MSW Technical Intelligence Engine','version':APP_VERSION,'modules':{
                'families':len(FAMILIES),'technical_specializations':len(TAXONOMY),'agent_profiles':len(AGENTS),
                'profiles_running':0,'lessons':len(LESSONS),'labs':len(LABS), 'tools_described':len(TOOLS),
                'integrations_described':len(ENGINE_ADAPTERS), 'live_device_integrations':0,
                'research_sources':len(SOURCES)},
            'research':{'status':research.get('status','no_verified_run'),'last_attempt':research.get('checked_at'),'candidate_count':len(research.get('items',[])),
                        'public_material_approved':False,'autonomous_model_training':False},
            'link_audit':{'status':audit.get('status','not_checked'),'last_checked':audit.get('checked_at'), 'checked':len(audit.get('results',[]))},
            'security':{'data_kind':'editorial curriculum','real_equipment_tested':False,'remote_hardware_access':False,
                        'external_models_authenticated':False,'public_submissions':'disabled_until_moderated_storage_configured'},
            'referenced_taxonomy':'MSW original taxonomy inspired by ESCO; not 1000 official science disciplines',
            'dataset_hash':hashlib.sha256(DATAFILE.read_bytes()).hexdigest()}

@app.get('/api/families')
def families(group: str='',page:int=Query(1,ge=1),size:int=Query(20,ge=1,le=MAX_QUERY)):
    items=[x for x in FAMILIES if not group or x['group']==group]
    return _page(items,page,size)

@app.get('/api/specializations')
def specializations(q:str=Query('',max_length=100),group:str='',page:int=Query(1,ge=1),size:int=Query(24,ge=1,le=MAX_QUERY)):
    return _page(_filter(TAXONOMY,q,group,('title','family','subfield','description','id')),page,size)

@app.get('/api/agents')
def agents(q:str=Query('',max_length=100),group:str='',page:int=Query(1,ge=1),size:int=Query(24,ge=1,le=MAX_QUERY)):
    items=_filter(AGENTS,q,group,('name','family','topic','id'))
    return _page(items,page,size)

@app.get('/api/tracks')
def tracks():
    return {'items':TRACKS,'count':len(TRACKS)}

@app.get('/api/materials')
def materials(kind:str='all',track:str='',q:str=Query('',max_length=100),page:int=Query(1,ge=1),size:int=Query(24,ge=1,le=MAX_QUERY)):
    if kind not in ('all','lesson','lab'):
        raise HTTPException(422,'kind must be all, lesson or lab')
    if track and track not in {x['slug'] for x in TRACKS}:
        raise HTTPException(422,'unknown track')
    source=INDEX if kind=='all' else LESSONS if kind=='lesson' else LABS
    return _page([x for x in source if (not track or x['track']==track) and
                  (not q or q.casefold() in (x['title']+' '+x['topic']).casefold())],page,size)

@app.get('/api/material/{record_id}')
def material(record_id:str):
    meta=INDEX_BY_ID.get(record_id)
    if not meta:raise HTTPException(404,'unknown material')
    track=get_data('tracks/'+meta['track']+'.json')
    collection=track['lessons' if meta['kind']=='lesson' else 'labs']
    data=next((x for x in collection if x['id']==record_id),None)
    if not data:raise HTTPException(404,'material not found in verified bundle')
    return {'item':data,'source_url':track['track'].get('source'),
            'content_status':'original_educational_curriculum_not_hardware_verified',
            'moderation':'generated_editorial_checked_locally'}

@app.get('/api/tools')
def tools_list(q:str=Query('',max_length=100),page:int=Query(1,ge=1),size:int=Query(40,ge=1,le=100)):
    data=[x for x in TOOLS if not q or q.casefold() in (x['name']+' '+x['sector']).casefold()]
    return _page(data,page,size)

@app.get('/api/learning-plan')
def learning_plan():
    date=datetime.now(timezone.utc)
    d=date.timetuple().tm_yday
    assigned_l=[LESSONS[(d*11+i)%len(LESSONS)] for i in range(12)]
    assigned_b=[LABS[(d*13+i)%len(LABS)] for i in range(16)]
    assigned_a=[AGENTS[(d*40+i)%len(AGENTS)] for i in range(40)]
    return {'date_utc':date.date().isoformat(), 'lessons':[{'id':x['id'],'title':x['title']} for x in assigned_l],
            'labs':[{'id':x['id'],'title':x['title']} for x in assigned_b],
            'agent_profiles':[{'id':x['id'],'name':x['name']} for x in assigned_a],
            'status':'read_only_learning_plan_not_executed','inference_jobs_executed':0,'model_weights_changed':False,
            'rule':'Tylko zatwierdzona wiedza i dane autoryzowane mogą zasilać rzeczywiste procesy agentów.'}

@app.get('/api/integrations')
def integrations():
    return {'adapters':ENGINE_ADAPTERS,'live_bridge_verified':False,
            'note':'Status odczytowy z wcześniejszego audytu; bez danych uwierzytelniających integracje nie są aktywne.'}

@app.get('/api/quantum')
def quantum():
    return {'providers':QUANTUM,'real_qpu_jobs':0,'local_simulator_available':True,
            'hardware_claims':'none','notes':'IBM account and token / Google approved access required; NASA QuAIL is research, not free public QPU.'}

@app.get('/api/quantum/bell')
def bell():
    # Exact analytic local calculation, H(q0) followed by CNOT, no external QPU.
    a=1/math.sqrt(2)
    return {'experiment':'Bell pair H(q0), CNOT(q0,q1)','probabilities':{'00':a*a,'01':0,'10':0,'11':a*a},
            'measurement_samples':None, 'execution':'analytic_cpu_only', 'hardware_connected':False,
            'source':'elementary quantum circuit identity'}

@app.get('/api/research/sources')
def research_sources():
    report=load_report('research/candidates.json')
    return {'items':SOURCES,'count':len(SOURCES),'automated_research':'GitHub Actions scheduled pending approval of workflow execution',
            'last_run':report.get('checked_at'), 'last_status':report.get('status','not_run'),
            'editorial_policy':'external metadata -> unreviewed -> human review -> published knowledge (separate platform)'}

@app.get('/api/research/candidates')
def research_candidates(page:int=Query(1,ge=1),size:int=Query(20,ge=1,le=50)):
    r=load_report('research/candidates.json')
    return {'status':r.get('status','not_run'),'checked_at':r.get('checked_at'),
            **_page(r.get('items',[]),page,size),
            'moderation':'pending_human_review_not_published_as_approved_knowledge'}

@app.get('/api/audit/links')
def audit_links():
    return load_report('research/link-audit.json')

@app.get('/api/audit/pages')
def target_pages():
    return {'targets':[{'title':x,'url':'https://mobilny-serwis-warszawa.pl/'+slug+'/'} for x,slug in PAGES],
            'scope':'selected project pages; site-wide completeness is not established',
            'links_verified_now':False}

@app.post('/api/peer/messages')
def peer_messages():
    raise HTTPException(503,'Moderated authenticated message delivery not configured on standalone engine; use existing WordPress University agent API after authorization.')

@app.post('/api/research/approve')
def research_approve():
    raise HTTPException(503,'No standalone approval database or verified editor login. Review in WordPress after authorized integration.')

@app.get('/api/metadata')
def metadata():
    return {'api_name':'MSW Technical Intelligence Engine','schema_version':'1.0',
            'read_only_endpoints':['/api/status','/api/families','/api/specializations','/api/agents',
                                   '/api/materials','/api/material/{id}','/api/tools','/api/learning-plan','/api/research/candidates'],
            'peer_protocol':'manual review + separately authenticated agent gateway',
            'no_device_control':True,'api_docs':'/api/docs'}


def load_report(filename:str)->dict:
    if filename not in {'research/candidates.json','research/link-audit.json'}:return {}
    p=HERE/filename
    try:
        doc=json.loads(p.read_text(encoding='utf-8'))
        return doc if isinstance(doc,dict) else {}
    except (OSError,ValueError):return {}
