import unittest
from fastapi.testclient import TestClient
from msw_technical_intelligence_engine import app as mod

class EngineChecks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.c=TestClient(mod.app)
    def test_health(self):
        x=self.c.get('/health').json();self.assertTrue(x['data_loaded']);self.assertFalse(x['hardware_connected'])
    def test_status(self):
        x=self.c.get('/api/status').json()['modules']; self.assertEqual((x['technical_specializations'],x['agent_profiles'],x['lessons'],x['labs']), (1000,1000,1200,1600));self.assertEqual(x['profiles_running'],0)
    def test_catalog(self):
        x=self.c.get('/api/specializations?size=12').json();self.assertEqual(x['total'],1000);self.assertEqual(len(x['items']),12)
    def test_group_filters(self):
        x=self.c.get('/api/specializations?group=DOMY').json();self.assertTrue(x['items']);self.assertTrue(all(y['macro_domain']=='DOMY' for y in x['items']))
    def test_material(self):
        x=self.c.get('/api/materials?kind=lab').json();self.assertEqual(x['total'],1600)
        y=self.c.get('/api/material/'+x['items'][0]['id']).json();self.assertEqual(y['item']['kind'],'lab');self.assertIn('procedura',y['item']['content'])
    def test_no_write(self):
        self.assertEqual(self.c.post('/api/peer/messages',json={}).status_code,503)
        self.assertEqual(self.c.post('/api/research/approve',json={}).status_code,503)
    def test_quantum(self):
        x=self.c.get('/api/quantum/bell').json();self.assertAlmostEqual(sum(x['probabilities'].values()),1);self.assertFalse(x['hardware_connected'])
    def test_path_traversal(self):
        with self.assertRaises(ValueError):mod.get_data('../../../etc/passwd')
        self.assertEqual(self.c.get('/api/material/no-such-id').status_code,404)
    def test_research_is_unapproved(self):
        x=self.c.get('/api/research/candidates').json();self.assertIn('pending_human_review',x['moderation'])
    def test_existing_pages_preserved(self):
        x=self.c.get('/api/audit/pages').json();self.assertFalse(x['links_verified_now']);self.assertGreaterEqual(len(x['targets']),15)

if __name__ == '__main__':unittest.main()
